VC9 x64 Non Thread Safe compiled LibXL plug-in for PHP 5.2 
(Ilia Alshanetsky https://github.com/iliaal/php_excel)



