VC15 x64 Non Thread Safe compiled LibXL plug-in for PHP 7.2 
(Ilia Alshanetsky https://github.com/iliaal/php_excel)



