VS16 x64 Non Thread Safe compiled LibXL plug-in for PHP 8.1
(Ilia Alshanetsky https://github.com/iliaal/php_excel)
